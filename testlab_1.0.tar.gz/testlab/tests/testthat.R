library(testthat)
library(testlab)

test_check("testlab")